"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '', 
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

// Fallback theme if database fetch fails
const DEFAULT_THEME = {
  logoType: 'text',
  logoText: 'WebIMS',
  logoUrl: '',
  bgType: 'animated',
  bgColor: '#f8fafc',
  bgImageUrl: '',
  bgGradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  cardBg: '#ffffff',
  cardRadius: 24, 
  primaryColor: '#4f46e5',
  inputBg: '#f8fafc',
  inputTextColor: '#1e293b',
  inputRadius: 12,
  fontFamily: 'inter',
  loginHeading: 'Welcome Back!',
  loginSub: 'Sign in to manage your inventory and distributions.',
  regHeading: 'Request Access',
  regSub: 'Register your details. Admin approval is required.'
};

export default function LoginPage() {
  const router = useRouter();
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [roles, setRoles] = useState<any[]>([]);
  const [isThemeLoading, setIsThemeLoading] = useState(true);
  
  // Form States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [designation, setDesignation] = useState('');
  const [roleId, setRoleId] = useState('');
  
  // Action States
  const [isProcessing, setIsProcessing] = useState(false);
  const [msg, setMsg] = useState({ text: '', type: '' });

  useEffect(() => {
    // Check if user is already logged in
    const session = localStorage.getItem('user_session');
    if (session) {
       router.push('/dashboard'); 
    }
    fetchThemeAndRoles();
  }, [router]);

  const showMessage = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg({ text: '', type: '' }), 5000);
  };

  const fetchThemeAndRoles = async () => {
    try {
      const [{ data: themeData }, { data: rolesData }] = await Promise.all([
          supabase.from('app_settings').select('settings').eq('id', 'login_page_design').single(),
          supabase.from('user_roles').select('*')
      ]);

      if (themeData && themeData.settings) {
          setTheme({ ...DEFAULT_THEME, ...themeData.settings });
      }
      if (rolesData) {
          // Filter out Super Admin and Admin from registration
          const filteredRoles = rolesData.filter(r => 
              !['Super Admin', 'Admin', 'WEB ADMIN'].includes(r.role_name)
          );
          setRoles(filteredRoles);
          if (filteredRoles.length > 0) setRoleId(filteredRoles[0].id);
      }
    } catch (err) {
      console.error("Data load error");
    } finally {
      setIsThemeLoading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsProcessing(true);
      setMsg({ text: '', type: '' });

      if (isLoginMode) {
          // ================= LOGIN FLOW =================
          try {
              const { data: user, error } = await supabase
                  .from('profiles')
                  .select('*, user_roles(role_name)')
                  .eq('email', email.toLowerCase().trim())
                  .eq('password_hash', password)
                  .single();

              if (error || !user) {
                  showMessage("Invalid email or password.", "error");
                  setIsProcessing(false);
                  return;
              }

              if (user.status === 'Pending') {
                  showMessage("Your account is pending Admin approval. Please wait.", "error");
                  setIsProcessing(false);
                  return;
              } else if (user.status !== 'Active') {
                  showMessage(`Your account is currently ${user.status}. Please contact support.`, "error");
                  setIsProcessing(false);
                  return;
              }

              // Save session securely
              localStorage.setItem('user_session', JSON.stringify(user));
              showMessage("Login successful! Redirecting...");
              
              setTimeout(() => {
                  router.push('/dashboard'); 
              }, 1000);

          } catch (err: any) {
              showMessage("An error occurred during login.", "error");
          }
      } else {
          // ================= REGISTRATION FLOW =================
          if (!roleId) {
              showMessage("Please select a role.", "error");
              setIsProcessing(false);
              return;
          }
          if (password.length < 8) {
              showMessage("Password must be at least 8 characters long.", "error");
              setIsProcessing(false);
              return;
          }

          try {
              // Check existing email
              const { data: existing } = await supabase.from('profiles').select('id').eq('email', email.toLowerCase().trim()).single();
              
              if (existing) {
                  showMessage("An account with this email already exists.", "error");
                  setIsProcessing(false);
                  return;
              }

              // Insert New Profile with 'Pending' Status
              const payload = {
                  id: crypto.randomUUID(),
                  email: email.toLowerCase().trim(),
                  full_name: fullName.trim(),
                  phone: phone.trim(),
                  designation: designation.trim(),
                  password_hash: password,
                  status: 'Pending', // Requires Admin Approval
                  role_id: roleId 
              };

              const { error } = await supabase.from('profiles').insert([payload]);
              
              if (error) throw error;

              showMessage("Registration successful! Your account is Pending admin approval.", "success");
              setIsLoginMode(true);
              setPassword('');
              
          } catch (err: any) {
              showMessage(`Registration failed: ${err.message}`, "error");
          }
      }
      setIsProcessing(false);
  };

  const fontClasses: any = {
      'inter': 'font-sans',
      'serif': 'font-serif',
      'mono': 'font-mono'
  };

  const getBackgroundStyle = () => {
      if (theme.bgType === 'solid') return { backgroundColor: theme.bgColor };
      if (theme.bgType === 'image') return { backgroundImage: `url(${theme.bgImageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' };
      if (theme.bgType === 'gradient') return { backgroundImage: theme.bgGradient };
      return {}; 
  };

  if (isThemeLoading) {
      return (
         <div className="fixed inset-0 z-[9999] flex h-screen w-screen items-center justify-center bg-slate-50">
            <div className="animate-spin text-4xl">⏳</div>
         </div>
      );
  }

  return (
    // Fixed wrapper covers the entire viewport (hiding sidebars/topbars from layout.tsx)
    <div className="fixed inset-0 z-[9999] overflow-y-auto overflow-x-hidden bg-slate-50">
      <div className="relative min-h-screen w-full flex flex-col items-center justify-center py-12 px-4">
        
        {/* Animated Background CSS */}
        {theme.bgType === 'animated' && (
          <style dangerouslySetInnerHTML={{__html: `
            @keyframes gradientBG {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
            }
            .bg-animated-layer {
                background: linear-gradient(-45deg, ${theme.primaryColor}, #e73c7e, #23a6d5, #23d5ab);
                background-size: 400% 400%;
                animation: gradientBG 15s ease infinite;
                position: absolute;
                inset: 0;
                z-index: 0;
            }
          `}} />
        )}

        {/* Background Container */}
        <div 
           className={`absolute inset-0 z-0 ${theme.bgType === 'animated' ? 'bg-animated-layer' : ''}`}
           style={theme.bgType !== 'animated' ? getBackgroundStyle() : {}}
        />

        {/* Global Message Toast */}
        {msg.text && (
          <div className={`fixed top-6 left-1/2 -translate-x-1/2 z-[10000] p-4 rounded-xl shadow-2xl border text-sm font-bold flex items-center animate-in slide-in-from-top-4 ${msg.type === 'error' ? 'bg-rose-50 text-rose-700 border-rose-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
            <span className="mr-2 text-lg">{msg.type === 'error' ? '⚠️' : '✅'}</span> {msg.text}
          </div>
        )}

        {/* Content Container */}
        <div className={`relative z-10 w-full ${isLoginMode ? 'max-w-md' : 'max-w-lg'} transition-all duration-700 ${fontClasses[theme.fontFamily]}`}>
           <div 
              className="w-full overflow-hidden animate-in zoom-in-95 duration-500"
              style={{ 
                 backgroundColor: theme.cardBg, 
                 borderRadius: `${theme.cardRadius}px`, 
                 boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' 
              }}
           >
              <div className="p-8 sm:p-10 flex flex-col items-center text-center">
                 
                 {/* Full Text Logo */}
                 {theme.logoType === 'image' && theme.logoUrl ? (
                     <img src={theme.logoUrl} alt="Logo" className="h-14 object-contain mb-6 drop-shadow-sm" />
                 ) : (
                     <div className="px-6 py-3 rounded-2xl flex items-center justify-center text-white font-black text-3xl mb-6 shadow-lg bg-gradient-to-br from-white/20 to-black/20 tracking-tight" style={{ backgroundColor: theme.primaryColor }}>
                        {theme.logoText}
                     </div>
                 )}
                 
                 <h2 className="text-2xl font-black mb-2 transition-all" style={{ color: theme.inputTextColor }}>
                    {isLoginMode ? theme.loginHeading : theme.regHeading}
                 </h2>
                 <p className="text-sm font-medium opacity-70 transition-all" style={{ color: theme.inputTextColor }}>
                    {isLoginMode ? theme.loginSub : theme.regSub}
                 </p>
              </div>

              <form onSubmit={handleAuth} className="px-8 sm:px-10 pb-10 space-y-4">
                 
                 {!isLoginMode && (
                     <div className="animate-in slide-in-from-top-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2">
                           <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70" style={{ color: theme.inputTextColor }}>Full Name *</label>
                           <input 
                              type="text" 
                              value={fullName}
                              onChange={e => setFullName(e.target.value)}
                              required={!isLoginMode}
                              className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors" 
                              style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                           />
                        </div>
                        <div>
                           <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70" style={{ color: theme.inputTextColor }}>Phone Number</label>
                           <input 
                              type="text" 
                              value={phone}
                              onChange={e => setPhone(e.target.value)}
                              className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors" 
                              style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                           />
                        </div>
                        <div>
                           <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70" style={{ color: theme.inputTextColor }}>Designation</label>
                           <input 
                              type="text" 
                              value={designation}
                              onChange={e => setDesignation(e.target.value)}
                              className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors" 
                              style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                           />
                        </div>
                        <div className="sm:col-span-2">
                           <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70" style={{ color: theme.inputTextColor }}>Requested Role *</label>
                           <select 
                              value={roleId}
                              onChange={e => setRoleId(e.target.value)}
                              required={!isLoginMode}
                              className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors" 
                              style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                           >
                              <option value="" disabled>-- Select a Role --</option>
                              {roles.map(r => <option key={r.id} value={r.id}>{r.role_name}</option>)}
                           </select>
                        </div>
                     </div>
                 )}

                 <div>
                    <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70" style={{ color: theme.inputTextColor }}>Email Address *</label>
                    <input 
                       type="email" 
                       value={email}
                       onChange={e => setEmail(e.target.value)}
                       required
                       className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors" 
                       style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                    />
                 </div>

                 <div>
                    <label className="block text-[10px] font-bold uppercase mb-1.5 opacity-70 flex justify-between" style={{ color: theme.inputTextColor }}>
                       Password *
                       {isLoginMode && <span className="opacity-70 capitalize font-medium text-[9px] cursor-pointer hover:opacity-100">Forgot?</span>}
                    </label>
                    <input 
                       type="password" 
                       value={password}
                       onChange={e => setPassword(e.target.value)}
                       required
                       minLength={8}
                       className="w-full h-11 px-4 border shadow-inner font-bold outline-none transition-colors tracking-widest" 
                       style={{ backgroundColor: theme.inputBg, borderColor: theme.inputBg, borderRadius: `${theme.inputRadius}px`, color: theme.inputTextColor }} 
                    />
                    {!isLoginMode && <p className="text-[9px] mt-1 opacity-50" style={{ color: theme.inputTextColor }}>Minimum 8 characters required.</p>}
                 </div>

                 <div className="pt-4">
                    <button 
                       type="submit" 
                       disabled={isProcessing}
                       className="w-full h-12 text-white font-bold transition-transform hover:scale-[1.02] shadow-lg flex items-center justify-center disabled:opacity-50 disabled:hover:scale-100" 
                       style={{ backgroundColor: theme.primaryColor, borderRadius: `${theme.inputRadius}px` }}
                    >
                       {isProcessing ? (
                           <span className="animate-pulse">Processing...</span>
                       ) : (
                           isLoginMode ? 'Sign In Securely' : 'Submit Registration Request'
                       )}
                    </button>
                 </div>

                 <div className="text-center pt-4">
                    <button 
                       type="button"
                       onClick={() => {
                           setIsLoginMode(!isLoginMode);
                           setMsg({ text: '', type: '' });
                           setPassword('');
                       }}
                       className="text-[10px] font-medium opacity-60 hover:opacity-100 transition-opacity outline-none" 
                       style={{ color: theme.inputTextColor }}
                    >
                       {isLoginMode ? "Don't have an account? " : "Already have an account? "}
                       <span className="font-bold underline" style={{ color: theme.primaryColor }}>
                          {isLoginMode ? 'Register Here' : 'Login Here'}
                       </span>
                    </button>
                 </div>
              </form>
           </div>
           
           <p className="mt-8 text-center text-xs font-bold text-white/50">Powered by WebIMS Architecture</p>
        </div>
      </div>
    </div>
  );
}
