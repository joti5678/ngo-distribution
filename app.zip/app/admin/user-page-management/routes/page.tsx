"use client";

import React, { useState, useEffect, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '', 
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

// ============================================================================
// PERFECTLY MATCHED WITH SIDEBAR MAIN MENUS
// ============================================================================
const DEFAULT_APP_TREE = [
  {
    folder: 'Home Dashboard',
    items: [
      { path: '/dashboard', title: 'Main Dashboard Overview' }
    ]
  },
  {
    folder: 'Admin Panel',
    items: [
      { path: '/admin', title: 'Admin Control Panel' },
      { path: '/admin/dp-setup', title: 'Distribution Points (DPs)' },
      { path: '/admin/wh-setup', title: 'Warehouses (WH)' },
      { path: '/admin/dp-wh-connection', title: 'DP & WH Mapping' },
      { path: '/admin/partners', title: 'Partner Setup' },
      { path: '/admin/product-history', title: 'Product Audit History' },
      { path: '/admin/user-page-management', title: 'Access Control Hub' },
      { path: '/admin/user-page-management/roles', title: 'Role Management' },
      { path: '/admin/user-page-management/routes', title: 'Route Management' },
      { path: '/admin/user-page-management/access', title: 'Page Access Control' },
      { path: '/admin/user-page-management/users', title: 'User Management' },
      { path: '/admin/page-designer', title: 'UI Page Designer' }
    ]
  },
  {
    folder: 'Warehouse Management',
    items: [
      { path: '/warehouse', title: 'Warehouse Overview' },
      { path: '/warehouse/receive', title: 'Receive Stock' },
      { path: '/warehouse/entry', title: 'Stock Entry' },
      { path: '/warehouse/gap-damage', title: 'Gap & Damage' }
    ]
  },
  {
    folder: 'Distribution Point',
    items: [
      { path: '/distribution', title: 'Distribution Overview' },
      { path: '/distribution/manifests', title: 'Manifest Management' },
      { path: '/distribution/nfi-dist', title: 'NFI Distribution' }
    ]
  },
  {
    folder: 'Report & Reconciliation',
    items: [
      { path: '/reporting', title: 'Reporting Main' }
    ]
  },
  {
    folder: 'Database Management',
    items: [
      { path: '/database-management', title: 'Database Wipe / Hard Delete' }
    ]
  }
];

export default function RouteManagementPage() {
  const [appTree, setAppTree] = useState<any[]>([]);
  const [registeredRoutes, setRegisteredRoutes] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [msg, setMsg] = useState({ text: '', type: '' });

  const [isTreeModalOpen, setIsTreeModalOpen] = useState(false);
  const [treeModal, setTreeModal] = useState<{mode: 'add' | 'edit', type: 'folder' | 'page', data: any}>({ mode: 'add', type: 'page', data: null });
  const [treeForm, setTreeForm] = useState({ folderName: '', pageTitle: '', pagePath: '' });

  useEffect(() => {
    fetchInitialData();
  }, []);

  const showMessage = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg({ text: '', type: '' }), 4000);
  };

  const fetchInitialData = async () => {
    setIsLoading(true);
    const { data: treeData } = await supabase.from('app_settings').select('settings').eq('id', 'system_app_tree').single();
    if (treeData && treeData.settings) {
        setAppTree(treeData.settings);
    } else {
        setAppTree(DEFAULT_APP_TREE);
        await supabase.from('app_settings').upsert({ id: 'system_app_tree', settings: DEFAULT_APP_TREE });
    }

    const { data: routesData, error } = await supabase.from('app_routes').select('*').order('sort_order', { ascending: true });
    if (error) {
      showMessage("Error loading routes.", "error");
    } else if (routesData) {
      setRegisteredRoutes(routesData);
    }
    setIsLoading(false);
  };

  const saveTreeToDB = async (newTree: any[]) => {
      setAppTree(newTree);
      await supabase.from('app_settings').upsert({ id: 'system_app_tree', settings: newTree, updated_at: new Date().toISOString() });
  };

  const isRegistered = (path: string) => {
    return registeredRoutes.some(r => r.path === path);
  };

  const openTreeModal = (mode: 'add' | 'edit', type: 'folder' | 'page', data: any = null) => {
      setTreeModal({ mode, type, data });
      if (mode === 'edit') {
          if (type === 'folder') {
              setTreeForm({ folderName: data.folder, pageTitle: '', pagePath: '' });
          } else {
              setTreeForm({ folderName: data.folderName, pageTitle: data.title, pagePath: data.path });
          }
      } else {
          setTreeForm({ folderName: appTree.length > 0 ? appTree[0].folder : '', pageTitle: '', pagePath: '' });
      }
      setIsTreeModalOpen(true);
  };

  const handleSaveTreeItem = async (e: React.FormEvent) => {
      e.preventDefault();
      let newTree = [...appTree];

      if (treeModal.mode === 'add') {
          if (treeModal.type === 'folder') {
              if (!treeForm.folderName) return showMessage("Folder name required", "error");
              if (newTree.some(f => f.folder.toLowerCase() === treeForm.folderName.toLowerCase())) return showMessage("Folder already exists", "error");
              newTree.push({ folder: treeForm.folderName, items: [] });
              showMessage(`Folder '${treeForm.folderName}' created successfully!`);
          } else {
              const fIndex = newTree.findIndex(f => f.folder === treeForm.folderName);
              if (fIndex === -1) return showMessage("Invalid folder", "error");
              if (newTree[fIndex].items.some((i:any) => i.path === treeForm.pagePath)) return showMessage("Path already exists", "error");
              newTree[fIndex].items.push({ title: treeForm.pageTitle, path: treeForm.pagePath });
              showMessage(`Page '${treeForm.pageTitle}' added successfully!`);
          }
      } else {
          if (treeModal.type === 'folder') {
              const fIndex = newTree.findIndex(f => f.folder === treeModal.data.folder);
              if (fIndex > -1) {
                  newTree[fIndex].folder = treeForm.folderName;
                  await supabase.from('app_routes').update({ group_name: treeForm.folderName }).eq('group_name', treeModal.data.folder);
              }
              showMessage("Folder renamed successfully!");
          } else {
              const fIndex = newTree.findIndex(f => f.folder === treeModal.data.folderName);
              const pIndex = newTree[fIndex].items.findIndex((i:any) => i.path === treeModal.data.path);
              if (pIndex > -1) {
                  newTree[fIndex].items[pIndex] = { title: treeForm.pageTitle, path: treeForm.pagePath };
                  await supabase.from('app_routes').update({ title: treeForm.pageTitle, path: treeForm.pagePath }).eq('path', treeModal.data.path);
              }
              showMessage("Page updated successfully!");
          }
          fetchInitialData(); 
      }

      saveTreeToDB(newTree);
      setIsTreeModalOpen(false);
  };

  const handleDeleteTreeItem = async (type: 'folder' | 'page', folderName: string, path: string = '') => {
      if (!window.confirm(`Are you sure you want to delete this ${type}? It will also be removed from registered routes.`)) return;
      
      let newTree = [...appTree];
      if (type === 'folder') {
          newTree = newTree.filter(f => f.folder !== folderName);
          await supabase.from('app_routes').delete().eq('group_name', folderName);
      } else {
          const fIndex = newTree.findIndex(f => f.folder === folderName);
          if (fIndex > -1) {
              newTree[fIndex].items = newTree[fIndex].items.filter((i:any) => i.path !== path);
          }
          await supabase.from('app_routes').delete().eq('path', path);
      }
      
      showMessage(`System ${type} deleted successfully.`);
      saveTreeToDB(newTree);
      fetchInitialData();
  };

  const handleAddSingleRoute = async (item: any, folderName: string) => {
    if (isRegistered(item.path)) return;
    const payload = { title: item.title, path: item.path, group_name: folderName, is_active: true, sort_order: registeredRoutes.length };
    const { error } = await supabase.from('app_routes').insert([payload]);
    if (error) showMessage(error.message, "error");
    else fetchInitialData();
  };

  const handleAddFolder = async (folder: any) => {
    const unregisteredItems = folder.items.filter((item: any) => !isRegistered(item.path));
    if (unregisteredItems.length === 0) return; 

    const payloads = unregisteredItems.map((item: any, idx: number) => ({
        title: item.title, path: item.path, group_name: folder.folder, is_active: true, sort_order: registeredRoutes.length + idx
    }));
    const { error } = await supabase.from('app_routes').insert(payloads);
    if (error) showMessage(error.message, "error");
    else fetchInitialData();
  };

  const handleAddAllFolders = async () => {
    let payloads: any[] = [];
    appTree.forEach(folder => {
        const unregisteredItems = folder.items.filter((item:any) => !isRegistered(item.path));
        unregisteredItems.forEach((item:any) => {
            payloads.push({ title: item.title, path: item.path, group_name: folder.folder, is_active: true, sort_order: registeredRoutes.length + payloads.length });
        });
    });
    if (payloads.length === 0) return showMessage("All pages are already registered.");
    
    const { error } = await supabase.from('app_routes').insert(payloads);
    if (error) showMessage(error.message, "error");
    else fetchInitialData();
  };

  const handleRemoveRoute = async (id: string) => {
    const { error } = await supabase.from('app_routes').delete().eq('id', id);
    if (error) showMessage(error.message, "error");
    else setRegisteredRoutes(registeredRoutes.filter(r => r.id !== id));
  };

  const handleRemoveFolder = async (folderName: string) => {
    const routesToDelete = registeredRoutes.filter(r => r.group_name === folderName);
    if (routesToDelete.length === 0) return;
    const ids = routesToDelete.map(r => r.id);
    const { error } = await supabase.from('app_routes').delete().in('id', ids);
    if (error) showMessage(error.message, "error");
    else setRegisteredRoutes(registeredRoutes.filter(r => !ids.includes(r.id)));
  };

  const handleRemoveAll = async () => {
    if(!window.confirm("Are you sure you want to remove ALL registered pages?")) return;
    const ids = registeredRoutes.map(r => r.id);
    if (ids.length === 0) return;
    const { error } = await supabase.from('app_routes').delete().in('id', ids);
    if (error) showMessage(error.message, "error");
    else setRegisteredRoutes([]);
  };

  const handleToggleStatus = async (id: string, currentStatus: boolean) => {
      const newStatus = !currentStatus;
      const { error } = await supabase.from('app_routes').update({ is_active: newStatus }).eq('id', id);
      if (error) showMessage(error.message, "error");
      else setRegisteredRoutes(registeredRoutes.map(r => r.id === id ? { ...r, is_active: newStatus } : r));
  };

  const getGroupedRegisteredRoutes = () => {
      const grouped: { [key: string]: any[] } = {};
      appTree.forEach(folder => { grouped[folder.folder] = []; });
      registeredRoutes.forEach(route => {
          if (!grouped[route.group_name]) grouped[route.group_name] = [];
          grouped[route.group_name].push(route);
      });
      Object.keys(grouped).forEach(key => { if (grouped[key].length === 0) delete grouped[key]; });
      return grouped;
  };

  const groupedRoutes = getGroupedRegisteredRoutes();

  const FolderIcon = () => <svg className="w-5 h-5 text-indigo-400 mr-2 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M2 6a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" /></svg>;
  const FileIcon = () => <svg className="w-4 h-4 text-slate-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>;

  return (
    <div className="flex flex-col h-full bg-slate-50 w-full animate-in fade-in duration-500 overflow-hidden relative">
      
      {msg.text && (
        <div className={`fixed top-10 left-1/2 -translate-x-1/2 z-[9999] p-4 rounded-xl shadow-2xl border text-sm font-bold flex items-center animate-in slide-in-from-top-4 ${msg.type === 'error' ? 'bg-rose-50 text-rose-700 border-rose-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
          <span className="mr-2 text-lg">{msg.type === 'error' ? '⚠️' : '✅'}</span> {msg.text}
        </div>
      )}

      <header className="flex h-20 bg-white border-b border-slate-200 items-center px-4 md:px-6 shrink-0 shadow-sm z-10 justify-between">
        <div className="flex items-center">
            <button onClick={() => window.history.back()} className="mr-3 md:mr-4 p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors flex items-center justify-center" title="Back">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            </button>
            <div>
              <h1 className="text-lg md:text-xl font-black text-slate-900 tracking-tight">Route & Page Management</h1>
              <p className="text-[10px] md:text-xs font-bold text-slate-500 uppercase tracking-widest mt-0.5">Strict Access Control Registry</p>
            </div>
        </div>
      </header>

      <main className="flex-1 overflow-hidden p-4 md:p-6">
        <div className="flex flex-col xl:flex-row h-full gap-6">
           
           {/* LEFT PANE */}
           <div className="xl:w-1/2 flex flex-col bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden h-full">
             <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row justify-between sm:items-center gap-3 shrink-0">
               <div>
                 <h2 className="text-sm font-black text-slate-800 uppercase tracking-wide">Available System Pages</h2>
                 <p className="text-[10px] text-slate-500 font-medium mt-1">Select whole folder or specific pages to register.</p>
               </div>
               <div className="flex items-center space-x-2 shrink-0">
                  <button onClick={() => openTreeModal('add', 'page')} className="bg-white border border-slate-200 text-indigo-600 hover:border-indigo-300 font-bold py-2 px-3 rounded-lg text-xs shadow-sm transition-colors flex items-center">
                     <span className="mr-1 text-sm">+</span> Create New
                  </button>
                  <button onClick={handleAddAllFolders} className="bg-slate-800 hover:bg-slate-900 text-white font-bold py-2 px-3 rounded-lg text-xs shadow-sm transition-colors">
                     Add All Pages
                  </button>
               </div>
             </div>

             <div className="flex-1 overflow-y-auto p-4 md:p-5 custom-scrollbar space-y-4">
                {isLoading ? (
                   <div className="flex justify-center items-center h-full text-slate-400">Loading Directory...</div>
                ) : appTree.map((folder, fIdx) => {
                   const unregisteredItems = folder.items.filter((item:any) => !isRegistered(item.path));
                   const isFullyRegistered = unregisteredItems.length === 0;

                   return (
                     <div key={fIdx} className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm group/folder">
                       <div className="bg-slate-50 p-3 flex justify-between items-center border-b border-slate-100">
                          <div className="flex items-center">
                             <FolderIcon />
                             <span className={`font-black text-sm ${isFullyRegistered && folder.items.length > 0 ? 'text-slate-400' : 'text-slate-700'}`}>{folder.folder}</span>
                             <div className="hidden group-hover/folder:flex ml-3 space-x-1">
                                <button onClick={() => openTreeModal('edit', 'folder', folder)} className="p-1 text-amber-500 hover:bg-amber-50 rounded" title="Rename Folder"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                                <button onClick={() => handleDeleteTreeItem('folder', folder.folder)} className="p-1 text-rose-500 hover:bg-rose-50 rounded" title="Delete Folder"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                             </div>
                          </div>
                          <button 
                             onClick={() => handleAddFolder(folder)}
                             disabled={isFullyRegistered || folder.items.length === 0}
                             className={`text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors border ${isFullyRegistered || folder.items.length === 0 ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 shadow-sm'}`}
                          >
                             {isFullyRegistered && folder.items.length > 0 ? 'All Added' : '+ Add Folder'}
                          </button>
                       </div>
                       
                       <div className="divide-y divide-slate-50 p-1">
                          {folder.items.length === 0 && <p className="text-[10px] text-slate-400 p-3 italic text-center">Empty Folder</p>}
                          {folder.items.map((item:any, iIdx:number) => {
                             const registered = isRegistered(item.path);
                             return (
                               <div key={iIdx} className={`flex justify-between items-center p-2.5 transition-colors rounded-lg group/item ${registered ? 'opacity-40 bg-slate-50' : 'hover:bg-slate-50'}`}>
                                 <div className="flex flex-col ml-6 overflow-hidden pr-2">
                                    <div className="flex items-center">
                                       <FileIcon />
                                       <span className={`font-bold text-xs truncate ${registered ? 'text-slate-500 line-through' : 'text-slate-800'}`}>{item.title}</span>
                                       <div className="hidden group-hover/item:flex ml-3 space-x-1">
                                          <button onClick={() => openTreeModal('edit', 'page', { ...item, folderName: folder.folder })} className="p-1 text-amber-500 hover:bg-amber-100 rounded" title="Edit Page"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                                          <button onClick={() => handleDeleteTreeItem('page', folder.folder, item.path)} className="p-1 text-rose-500 hover:bg-rose-100 rounded" title="Delete Page"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                                       </div>
                                    </div>
                                    <span className="text-[9px] text-slate-400 font-mono ml-6 mt-0.5 truncate">{item.path}</span>
                                 </div>
                                 <button 
                                   onClick={() => handleAddSingleRoute(item, folder.folder)}
                                   disabled={registered}
                                   className={`w-7 h-7 flex items-center justify-center rounded-md shrink-0 transition-colors ${registered ? 'text-slate-300' : 'text-indigo-600 bg-white border border-slate-200 hover:border-indigo-400 shadow-sm'}`}
                                 >
                                    {registered ? <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg> : <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>}
                                 </button>
                               </div>
                             );
                          })}
                       </div>
                     </div>
                   );
                })}
             </div>
           </div>

           {/* RIGHT PANE */}
           <div className="xl:w-1/2 flex flex-col bg-white rounded-3xl shadow-sm border border-indigo-200 overflow-hidden h-full ring-4 ring-indigo-50/50">
             <div className="p-5 border-b border-indigo-100 bg-indigo-50/50 flex justify-between items-center shrink-0">
               <div>
                 <h2 className="text-sm font-black text-indigo-900 uppercase tracking-wide">Registered & Active Routes</h2>
                 <p className="text-[10px] text-indigo-500 font-medium mt-1">These pages can now be assigned to user roles.</p>
               </div>
               <div className="flex items-center space-x-3">
                  <span className="bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">{registeredRoutes.length} Pages</span>
                  <button onClick={handleRemoveAll} disabled={registeredRoutes.length === 0} className="p-1.5 text-rose-500 bg-white border border-rose-200 hover:bg-rose-50 hover:border-rose-300 rounded-lg transition-colors disabled:opacity-50" title="Remove All Registered Pages">
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
               </div>
             </div>

             <div className="flex-1 overflow-y-auto p-4 md:p-5 custom-scrollbar bg-slate-50/30">
                {isLoading ? (
                   <div className="flex justify-center items-center h-40 text-slate-400">Loading registered routes...</div>
                ) : registeredRoutes.length === 0 ? (
                   <div className="flex flex-col justify-center items-center h-full text-slate-400">
                      <span className="text-5xl mb-4 opacity-30">🛡️</span>
                      <p className="font-bold text-sm text-slate-500">No pages registered.</p>
                      <p className="text-xs mt-1">Select pages from the left panel to allow access.</p>
                   </div>
                ) : (
                   <div className="space-y-4">
                     {Object.entries(groupedRoutes).map(([groupName, routes]) => (
                        <div key={groupName} className="border border-indigo-100 rounded-xl overflow-hidden bg-white shadow-sm">
                           
                           <div className="bg-indigo-50/50 p-3 flex justify-between items-center border-b border-indigo-50">
                              <div className="flex items-center">
                                 <FolderIcon />
                                 <span className="font-black text-sm text-indigo-900">{groupName}</span>
                                 <span className="ml-2 bg-indigo-100 text-indigo-600 text-[9px] font-bold px-1.5 py-0.5 rounded">{routes.length}</span>
                              </div>
                              <button 
                                 onClick={() => handleRemoveFolder(groupName)}
                                 className="text-[10px] font-bold px-2 py-1 rounded text-rose-500 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors"
                              >
                                 Remove Folder
                              </button>
                           </div>

                           <div className="divide-y divide-slate-50 p-1">
                              {routes.map((route: any) => (
                                 <div key={route.id} className={`flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg transition-all ${route.is_active === false ? 'bg-slate-50 opacity-70' : 'hover:bg-slate-50'}`}>
                                    <div className="flex items-start space-x-3 mb-2 sm:mb-0 overflow-hidden flex-1 pl-6">
                                       <FileIcon />
                                       <div className="truncate">
                                          <h4 className={`font-bold text-xs truncate ${route.is_active === false ? 'text-slate-500 line-through' : 'text-slate-800'}`}>{route.title}</h4>
                                          <p className="text-[9px] text-slate-400 font-mono mt-0.5 truncate">{route.path}</p>
                                       </div>
                                    </div>
                                    
                                    <div className="flex items-center space-x-2 shrink-0 ml-12 sm:ml-0">
                                       <button 
                                          onClick={() => handleToggleStatus(route.id, route.is_active !== false)} 
                                          className={`px-2.5 py-1 rounded font-bold text-[9px] transition-colors uppercase border shadow-sm ${route.is_active !== false ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' : 'bg-slate-200 text-slate-500 border-slate-300 hover:bg-slate-300'}`}
                                       >
                                          {route.is_active !== false ? 'Active' : 'Inactive'}
                                       </button>
                                       
                                       <button 
                                          onClick={() => handleRemoveRoute(route.id)} 
                                          className="p-1 text-rose-400 bg-white hover:bg-rose-50 hover:text-rose-600 rounded border border-slate-200 hover:border-rose-200 transition-colors shadow-sm" 
                                          title="Remove Registration"
                                       >
                                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                       </button>
                                    </div>
                                 </div>
                              ))}
                           </div>

                        </div>
                     ))}
                   </div>
                )}
             </div>
           </div>
        </div>
      </main>

      {/* ========================================================= */}
      {/* DIRECTORY ADD/EDIT MODAL */}
      {/* ========================================================= */}
      {isTreeModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-black text-lg text-slate-900">{treeModal.mode === 'add' ? 'Add to Directory' : 'Edit Directory'}</h3>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">Virtual File System</p>
              </div>
              <button onClick={() => setIsTreeModalOpen(false)} className="p-2 bg-white border border-slate-200 text-slate-500 rounded-xl hover:bg-slate-100"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            
            <form onSubmit={handleSaveTreeItem} className="p-6 space-y-5">
               
               {/* Mode Selection for Add */}
               {treeModal.mode === 'add' && (
                 <div className="flex space-x-2 p-1 bg-slate-100 rounded-xl mb-4">
                    <button type="button" onClick={() => setTreeModal({...treeModal, type: 'page'})} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${treeModal.type === 'page' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500'}`}>📄 Add Page</button>
                    <button type="button" onClick={() => setTreeModal({...treeModal, type: 'folder'})} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${treeModal.type === 'folder' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500'}`}>📁 Add Folder</button>
                 </div>
               )}

               {/* Inputs */}
               {treeModal.type === 'folder' ? (
                   <div>
                     <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Folder Name *</label>
                     <input type="text" value={treeForm.folderName} onChange={e => setTreeForm({...treeForm, folderName: e.target.value})} required placeholder="e.g. Finance & Accounts" className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 font-bold outline-none focus:border-indigo-500 shadow-sm" />
                   </div>
               ) : (
                   <>
                     <div>
                       <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Parent Folder *</label>
                       {treeModal.mode === 'add' ? (
                           <select value={treeForm.folderName} onChange={e => setTreeForm({...treeForm, folderName: e.target.value})} required className="w-full px-4 py-3 bg-indigo-50 border border-indigo-200 rounded-xl text-sm text-indigo-900 font-bold outline-none focus:border-indigo-500 shadow-sm">
                             {appTree.map((f, i) => <option key={i} value={f.folder}>{f.folder}</option>)}
                           </select>
                       ) : (
                           <input type="text" value={treeForm.folderName} disabled className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-500 font-bold outline-none cursor-not-allowed" />
                       )}
                     </div>
                     <div>
                       <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Page Title *</label>
                       <input type="text" value={treeForm.pageTitle} onChange={e => setTreeForm({...treeForm, pageTitle: e.target.value})} required placeholder="e.g. Monthly Reports" className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 font-bold outline-none focus:border-indigo-500 shadow-sm" />
                     </div>
                     <div>
                       <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Page URL Path *</label>
                       <input type="text" value={treeForm.pagePath} onChange={e => setTreeForm({...treeForm, pagePath: e.target.value})} required placeholder="e.g. /reports/monthly" className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl text-sm font-mono text-slate-900 outline-none focus:border-indigo-500 shadow-sm" />
                     </div>
                   </>
               )}
               
               <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 rounded-xl text-sm transition-all shadow-lg flex justify-center items-center mt-6">
                 {treeModal.mode === 'add' ? '➕ Save to Directory' : '💾 Update Details'}
               </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
