"use client";

import React, { useState, useEffect, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '', 
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

export default function PageAccessControl() {
  const [roles, setRoles] = useState<any[]>([]);
  const [allRoutes, setAllRoutes] = useState<any[]>([]);
  
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  
  const [unassignedGroups, setUnassignedGroups] = useState<{ [key: string]: any[] }>({});
  const [assignedGroups, setAssignedGroups] = useState<{ [key: string]: any[] }>({});
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [msg, setMsg] = useState({ text: '', type: '' });

  useEffect(() => {
    fetchInitialData();
  }, []);

  const showMessage = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg({ text: '', type: '' }), 4000);
  };

  const fetchInitialData = async () => {
    setIsLoading(true);
    
    const { data: rolesData, error: rolesError } = await supabase.from('user_roles').select('*').order('created_at', { ascending: true });
    if (rolesError) showMessage("Error loading roles", "error");
    else setRoles(rolesData || []);

    const { data: routesData, error: routesError } = await supabase.from('app_routes').select('*').eq('is_active', true).order('sort_order', { ascending: true });
    if (routesError) showMessage("Error loading routes", "error");
    else setAllRoutes(routesData || []);

    setIsLoading(false);
  };

  const groupRoutes = (routesArray: any[]) => {
      return routesArray.reduce((acc: any, route: any) => {
          const group = route.group_name || 'General';
          if (!acc[group]) acc[group] = [];
          acc[group].push(route);
          return acc;
      }, {});
  };

  useEffect(() => {
    if (selectedRoleId) {
      loadRoleAccess(selectedRoleId);
    } else {
      setUnassignedGroups({});
      setAssignedGroups({});
    }
  }, [selectedRoleId, allRoutes]);

  const loadRoleAccess = async (roleId: string) => {
    const { data: accessData } = await supabase.from('role_route_access').select('route_id').eq('role_id', roleId);
    const assignedIds = accessData ? accessData.map(a => a.route_id) : [];
    
    const assigned = allRoutes.filter(r => assignedIds.includes(r.id));
    const unassigned = allRoutes.filter(r => !assignedIds.includes(r.id));
    
    setAssignedGroups(groupRoutes(assigned));
    setUnassignedGroups(groupRoutes(unassigned));
  };

  const handleGrantAccess = (route: any, groupName: string) => {
      const updatedUnassigned = { ...unassignedGroups };
      updatedUnassigned[groupName] = updatedUnassigned[groupName].filter(r => r.id !== route.id);
      if (updatedUnassigned[groupName].length === 0) delete updatedUnassigned[groupName];
      setUnassignedGroups(updatedUnassigned);

      const updatedAssigned = { ...assignedGroups };
      if (!updatedAssigned[groupName]) updatedAssigned[groupName] = [];
      updatedAssigned[groupName].push(route);
      setAssignedGroups(updatedAssigned);
  };

  const handleRevokeAccess = (route: any, groupName: string) => {
      const updatedAssigned = { ...assignedGroups };
      updatedAssigned[groupName] = updatedAssigned[groupName].filter(r => r.id !== route.id);
      if (updatedAssigned[groupName].length === 0) delete updatedAssigned[groupName];
      setAssignedGroups(updatedAssigned);

      const updatedUnassigned = { ...unassignedGroups };
      if (!updatedUnassigned[groupName]) updatedUnassigned[groupName] = [];
      updatedUnassigned[groupName].push(route);
      setUnassignedGroups(updatedUnassigned);
  };

  const handleGrantFolder = (groupName: string) => {
      const routesToMove = unassignedGroups[groupName] || [];
      if (routesToMove.length === 0) return;

      const updatedUnassigned = { ...unassignedGroups };
      delete updatedUnassigned[groupName];
      setUnassignedGroups(updatedUnassigned);

      const updatedAssigned = { ...assignedGroups };
      if (!updatedAssigned[groupName]) updatedAssigned[groupName] = [];
      updatedAssigned[groupName] = [...updatedAssigned[groupName], ...routesToMove];
      setAssignedGroups(updatedAssigned);
  };

  const handleRevokeFolder = (groupName: string) => {
      const routesToMove = assignedGroups[groupName] || [];
      if (routesToMove.length === 0) return;

      const updatedAssigned = { ...assignedGroups };
      delete updatedAssigned[groupName];
      setAssignedGroups(updatedAssigned);

      const updatedUnassigned = { ...unassignedGroups };
      if (!updatedUnassigned[groupName]) updatedUnassigned[groupName] = [];
      updatedUnassigned[groupName] = [...updatedUnassigned[groupName], ...routesToMove];
      setUnassignedGroups(updatedUnassigned);
  };

  const handleGrantAll = () => {
    setAssignedGroups(groupRoutes(allRoutes));
    setUnassignedGroups({});
  };

  const handleRevokeAll = () => {
    setUnassignedGroups(groupRoutes(allRoutes));
    setAssignedGroups({});
  };

  const handleSaveAccess = async () => {
    if (!selectedRoleId) return;
    setIsSaving(true);
    
    try {
      await supabase.from('role_route_access').delete().eq('role_id', selectedRoleId);
      
      const flatAssignedRoutes = Object.values(assignedGroups).flat();
      
      if (flatAssignedRoutes.length > 0) {
         const payload = flatAssignedRoutes.map((route: any) => ({
            role_id: selectedRoleId,
            route_id: route.id
         }));
         const { error } = await supabase.from('role_route_access').insert(payload);
         if (error) throw error;
      }
      
      showMessage("Access configuration saved successfully!");
    } catch (err: any) {
      showMessage(err.message, "error");
    } finally {
      setIsSaving(false);
    }
  };

  const FolderIcon = () => <svg className="w-5 h-5 text-indigo-400 mr-2 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M2 6a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" /></svg>;
  const FileIcon = () => <svg className="w-4 h-4 text-slate-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>;

  return (
    <div className="flex flex-col h-full bg-slate-50 w-full animate-in fade-in duration-500 overflow-hidden">
      
      <header className="flex h-20 bg-white border-b border-slate-200 items-center px-6 shrink-0 shadow-sm z-10 justify-between">
        <div className="flex items-center">
            <button onClick={() => window.history.back()} className="mr-4 p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors flex items-center justify-center" title="Back">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            </button>
            <div>
              <h1 className="text-xl font-black text-slate-900 tracking-tight">Page Access Control</h1>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-0.5">Role-based Route Mapping</p>
            </div>
        </div>
      </header>

      <main className="flex-1 overflow-hidden p-4 md:p-6 flex flex-col xl:flex-row gap-6 relative">
        
        {msg.text && (
          <div className={`absolute top-10 left-1/2 -translate-x-1/2 z-50 p-4 rounded-xl shadow-lg border text-sm font-bold flex items-center animate-in slide-in-from-top-4 ${msg.type === 'error' ? 'bg-rose-50 text-rose-700 border-rose-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
            <span className="mr-2 text-lg">{msg.type === 'error' ? '⚠️' : '✅'}</span> {msg.text}
          </div>
        )}

        <div className="xl:w-1/4 flex flex-col bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden h-full">
           <div className="p-5 border-b border-slate-100 bg-slate-900 text-white shrink-0">
             <h2 className="text-sm font-black uppercase tracking-wide">1. Select User Role</h2>
             <p className="text-[10px] text-slate-400 font-medium mt-1">Choose a role to configure access.</p>
           </div>
           
           <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-2 bg-slate-50/50">
              {isLoading ? (
                  <div className="text-center p-4 text-slate-400 text-sm font-bold">Loading...</div>
              ) : roles.map(role => (
                 <button 
                   key={role.id}
                   onClick={() => setSelectedRoleId(role.id)}
                   className={`w-full text-left p-4 rounded-xl transition-all border ${selectedRoleId === role.id ? 'bg-indigo-600 border-indigo-700 text-white shadow-md scale-[1.02]' : 'bg-white border-slate-200 hover:border-indigo-300 hover:shadow-sm text-slate-700'}`}
                 >
                    <div className="flex justify-between items-center">
                       <span className="font-black text-sm">{role.role_name}</span>
                       {role.role_name === 'Super Admin' && <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${selectedRoleId === role.id ? 'bg-indigo-700 border-indigo-500 text-white' : 'bg-rose-50 border-rose-200 text-rose-600'}`}>Core</span>}
                    </div>
                    <p className={`text-[10px] mt-1 line-clamp-2 leading-relaxed ${selectedRoleId === role.id ? 'text-indigo-200' : 'text-slate-500'}`}>{role.description || 'No description'}</p>
                 </button>
              ))}
           </div>
        </div>

        <div className="xl:w-3/4 flex flex-col h-full opacity-100 transition-opacity">
           
           {!selectedRoleId ? (
              <div className="flex-1 bg-white rounded-3xl border border-slate-200 border-dashed flex flex-col items-center justify-center text-slate-400 shadow-sm">
                 <span className="text-6xl mb-4 opacity-50">🔐</span>
                 <p className="font-bold text-lg text-slate-600">No Role Selected</p>
                 <p className="text-sm">Please select a role from the left menu to manage page access.</p>
              </div>
           ) : (
              <div className="flex-1 flex flex-col bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                 
                 <div className="p-5 border-b border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
                    <div>
                      <h2 className="text-sm font-black text-slate-800 uppercase tracking-wide">2. Configure Page Access</h2>
                      <p className="text-[10px] text-slate-500 font-medium mt-1">Assign pages folder by folder or individually.</p>
                    </div>
                    <button 
                       onClick={handleSaveAccess}
                       disabled={isSaving}
                       className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-6 rounded-xl shadow-md transition-all flex items-center disabled:opacity-50 text-xs"
                    >
                       {isSaving ? 'Saving...' : '💾 Save Access Configuration'}
                    </button>
                 </div>

                 <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-slate-100/50 p-4 md:p-6 gap-6">
                    
                    <div className="flex-1 flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                       <div className="bg-slate-100 p-4 border-b border-slate-200 flex justify-between items-center shrink-0">
                          <div>
                            <h3 className="font-bold text-slate-700 text-xs uppercase flex items-center"><span className="mr-2 text-base">🚫</span> Restricted</h3>
                          </div>
                          <button onClick={handleGrantAll} disabled={Object.keys(unassignedGroups).length === 0} className="text-[10px] font-bold bg-indigo-600 text-white px-3 py-1.5 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50">
                             Grant All &rarr;
                          </button>
                       </div>
                       <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar min-h-[150px]">
                          {Object.keys(unassignedGroups).length === 0 ? (
                             <div className="h-full flex items-center justify-center text-slate-400 text-xs font-bold">List is empty.</div>
                          ) : (
                             Object.entries(unassignedGroups).map(([groupName, routes]) => (
                                <div key={groupName} className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm">
                                   <div className="bg-slate-50 p-3 flex justify-between items-center border-b border-slate-100">
                                      <div className="flex items-center">
                                         <FolderIcon />
                                         <span className="font-black text-sm text-slate-700">{groupName}</span>
                                      </div>
                                      <button 
                                         onClick={() => handleGrantFolder(groupName)}
                                         className="text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors border bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 shadow-sm"
                                         title="Grant Access to Entire Folder"
                                      >
                                         Allow Folder &rarr;
                                      </button>
                                   </div>
                                   <div className="divide-y divide-slate-50 p-1">
                                      {routes.map(route => (
                                         <div key={route.id} className="flex justify-between items-center p-2.5 transition-colors rounded-lg hover:bg-slate-50 group">
                                           <div className="flex flex-col ml-6 overflow-hidden pr-2">
                                              <div className="flex items-center">
                                                 <FileIcon />
                                                 <span className="font-bold text-xs truncate text-slate-800">{route.title}</span>
                                              </div>
                                              <span className="text-[9px] text-slate-400 font-mono ml-6 mt-0.5 truncate">{route.path}</span>
                                           </div>
                                           <button 
                                             onClick={() => handleGrantAccess(route, groupName)}
                                             className="w-7 h-7 flex items-center justify-center rounded-md shrink-0 transition-colors text-indigo-600 bg-white border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50 shadow-sm"
                                             title="Grant Access"
                                           >
                                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                           </button>
                                         </div>
                                      ))}
                                   </div>
                                </div>
                             ))
                          )}
                       </div>
                    </div>

                    <div className="flex-1 flex flex-col bg-white rounded-2xl border border-indigo-200 shadow-sm overflow-hidden ring-4 ring-indigo-50/50">
                       <div className="bg-indigo-50 p-4 border-b border-indigo-100 flex justify-between items-center shrink-0">
                          <div>
                            <h3 className="font-bold text-indigo-900 text-xs uppercase flex items-center"><span className="mr-2 text-base">✅</span> Allowed Access</h3>
                          </div>
                          <button onClick={handleRevokeAll} disabled={Object.keys(assignedGroups).length === 0} className="text-[10px] font-bold bg-rose-50 text-rose-600 border border-rose-200 px-3 py-1.5 rounded-lg hover:bg-rose-100 transition-colors shadow-sm disabled:opacity-50">
                             &larr; Revoke All
                          </button>
                       </div>
                       <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar min-h-[150px]">
                          {Object.keys(assignedGroups).length === 0 ? (
                             <div className="h-full flex items-center justify-center text-slate-400 text-xs font-bold">No pages assigned yet.</div>
                          ) : (
                             Object.entries(assignedGroups).map(([groupName, routes]) => (
                                <div key={groupName} className="border border-indigo-100 rounded-xl overflow-hidden bg-white shadow-sm">
                                   <div className="bg-indigo-50/50 p-3 flex justify-between items-center border-b border-indigo-100">
                                      <div className="flex items-center">
                                         <FolderIcon />
                                         <span className="font-black text-sm text-indigo-900">{groupName}</span>
                                      </div>
                                      <button 
                                         onClick={() => handleRevokeFolder(groupName)}
                                         className="text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors border bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100 shadow-sm"
                                         title="Revoke Access from Entire Folder"
                                      >
                                         &larr; Revoke Folder
                                      </button>
                                   </div>
                                   <div className="divide-y divide-slate-50 p-1">
                                      {routes.map(route => (
                                         <div key={route.id} className="flex justify-between items-center p-2.5 transition-colors rounded-lg hover:bg-slate-50 group">
                                           <div className="flex flex-col ml-6 overflow-hidden pr-2">
                                              <div className="flex items-center">
                                                 <FileIcon />
                                                 <span className="font-bold text-xs truncate text-slate-800">{route.title}</span>
                                              </div>
                                              <span className="text-[9px] text-indigo-400 font-mono ml-6 mt-0.5 truncate">{route.path}</span>
                                           </div>
                                           <button 
                                             onClick={() => handleRevokeAccess(route, groupName)}
                                             className="w-7 h-7 flex items-center justify-center rounded-md shrink-0 transition-colors text-rose-500 bg-rose-50 border border-rose-100 hover:border-rose-300 hover:bg-rose-100 shadow-sm"
                                             title="Revoke Access"
                                           >
                                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                           </button>
                                         </div>
                                      ))}
                                   </div>
                                </div>
                             ))
                          )}
                       </div>
                    </div>

                 </div>
              </div>
           )}

        </div>
      </main>
    </div>
  );
}
