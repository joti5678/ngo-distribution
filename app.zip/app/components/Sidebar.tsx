"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Icons } from './Icons';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

const SYSTEM_CONFIG = {
  appName: "NGO Connect",
  logoInitials: "NC",
};

const MAIN_MENUS = [
  { id: '/dashboard', label: 'Home Dashboard', icon: <Icons.Dashboard />, folderMatch: 'Home Dashboard' },
  { id: '/admin', label: 'Admin Panel', icon: <Icons.Users />, folderMatch: 'Admin Panel' },
  { id: '/warehouse', label: 'Warehouse Management', icon: <Icons.Catalog />, folderMatch: 'Warehouse Management' },
  { id: '/distribution', label: 'Distribution Point', icon: <Icons.Manifest />, folderMatch: 'Distribution Point' },
  { id: '/reporting', label: 'Report & Reconciliation', icon: <Icons.Filter />, folderMatch: 'Report & Reconciliation' },
  { id: '/database-management', label: '⚠️ Database Management', icon: <Icons.Plus />, folderMatch: 'Database Management' },
];

export default function Sidebar({ isOpen, setIsOpen }: { isOpen: boolean, setIsOpen: (val: boolean) => void }) {
  const pathname = usePathname();
  const router = useRouter();
  
  const [userRole, setUserRole] = useState<string>('Loading...'); 
  const [allowedGroups, setAllowedGroups] = useState<string[]>([]);
  const [allowedRoutes, setAllowedRoutes] = useState<any[]>([]);
  const [isSuper, setIsSuper] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUserAndMenu();
  }, [pathname]);

  const loadUserAndMenu = async () => {
    setIsLoading(true);
    try {
      const sessionStr = localStorage.getItem('user_session');
      if (!sessionStr) {
         router.push('/login');
         return;
      }
      
      const user = JSON.parse(sessionStr);
      const roleName = user.user_roles?.role_name || 'User';
      setUserRole(roleName);

      const roleNameUpper = roleName.toUpperCase();
      const isSuperAdmin = roleNameUpper.includes('SUPER ADMIN') || roleNameUpper.includes('WEB ADMIN') || roleNameUpper === 'ADMIN';
      setIsSuper(isSuperAdmin);

      if (isSuperAdmin) {
          setAllowedGroups(MAIN_MENUS.map(m => m.folderMatch));
      } else if (user.role_id) {
          const { data: accessData } = await supabase
              .from('role_route_access')
              .select('route_id')
              .eq('role_id', user.role_id);
          
          if (accessData && accessData.length > 0) {
              const routeIds = accessData.map(a => a.route_id);
              
              const { data: routesData } = await supabase
                  .from('app_routes')
                  .select('*')
                  .in('id', routeIds)
                  .eq('is_active', true)
                  .order('sort_order', { ascending: true });

              if (routesData) {
                  setAllowedRoutes(routesData); // Save full route details for smart linking
                  const groups = Array.from(new Set(routesData.map(r => r.group_name).filter(Boolean))) as string[];
                  setAllowedGroups(groups);
              }
          }
      }
    } catch (error) {
      console.error("Error loading sidebar menu:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const visibleMenus = MAIN_MENUS.filter(menu => allowedGroups.includes(menu.folderMatch));
  const dynamicFolders = allowedGroups.filter(ag => !MAIN_MENUS.some(m => m.folderMatch === ag));

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 z-40 md:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={`fixed md:static inset-y-0 left-0 z-50 w-72 bg-slate-900 text-slate-300 flex flex-col h-screen transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'} border-r border-slate-800 shrink-0 shadow-2xl md:shadow-none`}>
        
        <div className="p-6 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-cyan-500 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
              {SYSTEM_CONFIG.logoInitials}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide">{SYSTEM_CONFIG.appName}</h2>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">{userRole}</p>
            </div>
          </div>
          <button onClick={() => setIsOpen(false)} className="md:hidden text-slate-400 hover:text-white">
            <Icons.Close />
          </button>
        </div>

        <div className="px-6 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider shrink-0">Main Navigation</div>
        
        <nav className="flex-1 px-4 space-y-1 mt-2 overflow-y-auto pb-6 custom-scrollbar">
          {isLoading ? (
            <div className="px-4 py-2 text-sm text-slate-500">Loading Access...</div>
          ) : visibleMenus.length === 0 && dynamicFolders.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-slate-500">
               <span className="text-2xl mb-2 block opacity-50">🔒</span>
               No menus available.
            </div>
          ) : (
            <>
              {visibleMenus.map((menu) => {
                const isActive = menu.id === '/' ? pathname === '/' : pathname.startsWith(menu.id); 
                
                // SMART ROUTING LOGIC: Find the exact sub-page the user is allowed to access
                let targetHref = menu.id;
                if (!isSuper) {
                    const exactRoute = allowedRoutes.find(r => r.path === menu.id);
                    if (!exactRoute) {
                        // If they don't have access to the main page (e.g. /distribution),
                        // send them to the FIRST page they DO have access to in that folder!
                        const fallbackRoute = allowedRoutes.find(r => r.group_name === menu.folderMatch);
                        if (fallbackRoute) {
                            targetHref = fallbackRoute.path;
                        }
                    }
                }

                return (
                  <Link 
                    key={menu.id} 
                    href={targetHref}
                    onClick={() => setIsOpen(false)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                      isActive 
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' 
                        : 'hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {menu.icon} 
                    <span className="text-sm font-medium">{menu.label}</span>
                  </Link>
                );
              })}

              {/* Dynamically added folders */}
              {dynamicFolders.map((dynFolder, idx) => {
                 let targetHref = '/dashboard';
                 if (!isSuper) {
                     const fallbackRoute = allowedRoutes.find(r => r.group_name === dynFolder);
                     if (fallbackRoute) targetHref = fallbackRoute.path;
                 }
                 
                 return (
                  <Link 
                    key={`dyn-${idx}`} 
                    href={targetHref}
                    onClick={() => setIsOpen(false)}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all hover:bg-slate-800 hover:text-white"
                  >
                    <svg className="w-5 h-5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>
                    <span className="text-sm font-medium">{dynFolder}</span>
                  </Link>
                 )
              })}
            </>
          )}
        </nav>
      </aside>
    </>
  );
}
