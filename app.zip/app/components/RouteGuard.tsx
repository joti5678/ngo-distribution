"use client";

import React, { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '', 
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

export default function RouteGuard({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const [isAuthorized, setIsAuthorized] = useState(false);

    useEffect(() => {
        checkSecurityAccess();
    }, [pathname]);

    const checkSecurityAccess = async () => {
        // 1. Allow Public Routes immediately
        if (pathname === '/login' || pathname === '/') {
            setIsAuthorized(true);
            return;
        }

        // 2. Check Session
        const sessionStr = localStorage.getItem('user_session');
        if (!sessionStr) {
            router.push('/login');
            return;
        }

        const user = JSON.parse(sessionStr);
        const roleName = user.user_roles?.role_name?.toUpperCase() || '';
        
        // 3. Super Admin bypass (Has access to everything)
        if (roleName.includes('SUPER ADMIN') || roleName.includes('WEB ADMIN') || roleName === 'ADMIN') {
            setIsAuthorized(true);
            return;
        }

        // 4. Always allow standard generic pages for logged-in users
        if (pathname === '/dashboard' || pathname === '/profile') {
            setIsAuthorized(true);
            return;
        }

        // 5. Normal User Strict Security Check
        try {
            // First, find if this route is registered in the database
            const { data: route } = await supabase
                .from('app_routes')
                .select('id, is_active')
                .eq('path', pathname)
                .single();

            // If it's a completely unregistered route, restrict it (Strict mode)
            if (!route) {
                console.warn(`Route ${pathname} is not registered in DB.`);
                router.push('/dashboard');
                return;
            }

            // If route is marked inactive globally
            if (!route.is_active) {
                router.push('/dashboard');
                return;
            }

            // Finally, check if this specific user's role has mapping to this route ID
            const { data: access } = await supabase
                .from('role_route_access')
                .select('id')
                .eq('role_id', user.role_id)
                .eq('route_id', route.id)
                .single();

            if (!access) {
                // User does not have access! Kick them to dashboard.
                router.push('/dashboard');
                return;
            }

            // Passed all checks!
            setIsAuthorized(true);

        } catch (error) {
            console.error("Access verification failed", error);
            router.push('/dashboard');
        }
    };

    if (!isAuthorized && pathname !== '/login' && pathname !== '/') {
        return (
            <div className="fixed inset-0 z-[99999] flex flex-col h-screen w-screen items-center justify-center bg-slate-50">
                <div className="w-12 h-12 border-4 border-rose-200 border-t-rose-600 rounded-full animate-spin mb-4"></div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest animate-pulse">Verifying Security Access...</p>
            </div>
        );
    }

    return <>{children}</>;
}
