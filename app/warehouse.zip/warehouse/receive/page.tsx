"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Icons } from '../../components/Icons';
import { createClient } from '@supabase/supabase-js';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '', 
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

export default function ProductReceivePage() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [allowedWarehouses, setAllowedWarehouses] = useState<any[]>([]);
  const [allWarehouses, setAllWarehouses] = useState<any[]>([]);
  
  // Top Filter States
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('');
  const [filterDate, setFilterDate] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Data States
  const [pendingTransfers, setPendingTransfers] = useState<any[]>([]);
  const [recentReceives, setRecentReceives] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [msg, setMsg] = useState({ text: '', type: '' });

  // Action Modals States
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState<any>(null);
  const [transferItems, setTransferItems] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectStep, setRejectStep] = useState(1);

  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);

  useEffect(() => {
    fetchCoreData();
  }, []);

  const showMessage = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg({ text, type });
    setTimeout(() => setMsg({ text: '', type: '' }), 4500);
  };

  const fetchCoreData = async () => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
          setIsLoading(false);
          return;
      }
      setCurrentUser(user);
      
      const sessionStr = localStorage.getItem('user_session');
      const sessionUser = sessionStr ? JSON.parse(sessionStr) : null;
      
      // 1. Establish Role
      const sessionRole = String(sessionUser?.user_roles?.role_name || sessionUser?.role || '').toUpperCase();
      let isSuperAdmin = sessionRole.includes('SUPER ADMIN') || sessionRole === 'ADMIN' || sessionRole.includes('WEB ADMIN');

      if (!isSuperAdmin) {
          const { data: profile } = await supabase.from('profiles').select('*, user_roles(role_name)').eq('id', user.id).single();
          const dbRoleName = String(profile?.user_roles?.role_name || profile?.role || '').toUpperCase();
          if (dbRoleName.includes('SUPER ADMIN') || dbRoleName === 'ADMIN' || dbRoleName.includes('WEB ADMIN')) {
              isSuperAdmin = true;
          }
      }

      // 2. Bulletproof Logic for Fetching assigned_wh_ids (Taken EXACTLY from working Transfer page)
      let rawIds = sessionUser?.assigned_wh_ids;
      if (!rawIds && user?.id) {
          const { data: pData } = await supabase.from('profiles').select('assigned_wh_ids').eq('id', user.id).single();
          if (pData?.assigned_wh_ids) rawIds = pData.assigned_wh_ids;
          else {
              const { data: uData } = await supabase.from('users').select('assigned_wh_ids').eq('id', user.id).single();
              if (uData?.assigned_wh_ids) rawIds = uData.assigned_wh_ids;
          }
      }
      if (!rawIds && user?.user_metadata?.assigned_wh_ids) {
          rawIds = user.user_metadata.assigned_wh_ids;
      }

      let parsedWhIds: string[] = [];
      if (typeof rawIds === 'string') {
          try { parsedWhIds = JSON.parse(rawIds); } 
          catch { parsedWhIds = rawIds.replace(/[\[\]{}""']/g, '').split(','); }
      } else if (Array.isArray(rawIds)) {
          parsedWhIds = rawIds;
      } else if (rawIds && typeof rawIds === 'object') {
          parsedWhIds = Object.values(rawIds);
      }
      parsedWhIds = parsedWhIds.map((id: any) => String(id).trim()).filter((id: string) => id !== '');

      // 3. Fetch All Warehouses & Filter Allowed
      const { data: whData } = await supabase.from('warehouses').select('id, name, code').order('name');
      const allWhs = whData || [];
      setAllWarehouses(allWhs);

      const myWhs = isSuperAdmin ? allWhs : allWhs.filter(w => parsedWhIds.includes(String(w.id)));
      setAllowedWarehouses(myWhs);

      // Auto-select first warehouse if none is selected
      let initialWhId = selectedWarehouseId;
      if (!initialWhId && myWhs.length > 0) {
          initialWhId = myWhs[0].id;
          setSelectedWarehouseId(initialWhId);
      }

      // 4. Fetch Transfers & Transactions
      const [transfersRes, txnsRes] = await Promise.all([
          // Fetch ALL In-Transit Transfers targeted to WH
          supabase.from('stock_transfers').select('*').eq('status', 'In Transit').eq('destination_type', 'WH').order('created_at', { ascending: false }),
          // Fetch ALL IN transactions (Only related to transfers, explicitly ignoring Bulk Entries)
          supabase.from('inventory_transactions').select(`
            *,
            warehouses (name, code),
            products (name, code, unit_type, product_type),
            stock_transfers (from_warehouse_id)
          `)
          .eq('transaction_type', 'IN')
          .not('transfer_id', 'is', null) // <--- Strictly removes Bulk/Direct Entries from history
          .order('created_at', { ascending: false })
          .limit(300)
      ]);

      // Map Pending Transfers
      const allTransfers = transfersRes.data || [];
      const mappedTransfers = allTransfers.map(t => ({
          ...t,
          from_warehouse: allWhs.find(w => w.id === t.from_warehouse_id) || { name: 'Unknown' },
          to_warehouse: allWhs.find(w => w.id === t.to_warehouse_id) || { name: 'Unknown' }
      }));
      setPendingTransfers(mappedTransfers);

      // Map Receives History
      const allTxns = txnsRes.data || [];
      const mappedTxns = allTxns.map(txn => {
          let sourceName = 'Unknown Source';
          if (txn.stock_transfers?.from_warehouse_id) {
              const sWh = allWhs.find(w => w.id === txn.stock_transfers.from_warehouse_id);
              if (sWh) sourceName = sWh.name;
          }
          return { ...txn, exact_source: sourceName };
      });
      setRecentReceives(mappedTxns);

    } catch (error) {
      console.error("Error fetching data:", error);
      showMessage("Error loading data. Please check connection.", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const openTransferModal = async (transfer: any) => {
    setSelectedTransfer(transfer);
    setTransferModalOpen(true);
    try {
        const { data } = await supabase.from('stock_transfer_items').select('*').eq('transfer_id', transfer.id);
        if(data && data.length > 0) {
            const productIds = data.map(d => d.product_id);
            const { data: prods } = await supabase.from('products').select('*').in('id', productIds);
            const mappedItems = data.map(d => ({ ...d, products: prods?.find(p => p.id === d.product_id) }));
            setTransferItems(mappedItems);
        } else {
            setTransferItems([]);
        }
    } catch(e) {
        setTransferItems([]);
    }
  };

  const handleConfirmReceive = async () => {
    if(!selectedTransfer || transferItems.length === 0) return;
    setIsProcessing(true);

    try {
      const whId = selectedTransfer.to_warehouse_id;
      const ledgerEntries = [];
      const txnId = `TXN-${selectedTransfer.id.split('-')[0].toUpperCase()}`;

      for (const item of transferItems) {
        const { data: invRecord } = await supabase.from('inventory')
          .select('id, quantity').eq('warehouse_id', whId).eq('product_id', item.products.id).single();

        if (invRecord) {
          await supabase.from('inventory').update({ 
              quantity: invRecord.quantity + item.quantity, 
              last_updated: new Date().toISOString() 
          }).eq('id', invRecord.id);
        } else {
          await supabase.from('inventory').insert([{ 
              warehouse_id: whId, 
              product_id: item.products.id, 
              quantity: item.quantity 
          }]);
        }

        ledgerEntries.push({
          warehouse_id: whId,
          product_id: item.products.id,
          transaction_type: 'IN',
          quantity: item.quantity,
          reference_no: selectedTransfer.reference_no || null,
          transfer_id: selectedTransfer.id,
          remarks: `${txnId} | Received from ${selectedTransfer.from_warehouse?.name}`,
          created_by: currentUser?.id || null,
          created_by_email: currentUser?.email || null
        });
      }

      await supabase.from('inventory_transactions').insert(ledgerEntries);
      
      await supabase.from('stock_transfers').update({ 
        status: 'Received',
        updated_by: currentUser?.id || null,
        updated_by_email: currentUser?.email || null,
        updated_at: new Date().toISOString()
      }).eq('id', selectedTransfer.id);

      showMessage(`Successfully received transfer! System ID: ${txnId}`);
      setTransferModalOpen(false);
      await fetchCoreData(); 

    } catch (err: any) {
      showMessage(`Error receiving stock: ${err.message}`, "error");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectTransfer = async () => {
    if(!selectedTransfer) return;
    setIsProcessing(true);
    try {
      const { data: items } = await supabase.from('stock_transfer_items').select('product_id, quantity').eq('transfer_id', selectedTransfer.id);
      
      if (items) {
        for (const item of items) {
          const { data: currentInv } = await supabase.from('inventory').select('id, quantity').eq('warehouse_id', selectedTransfer.from_warehouse_id).eq('product_id', item.product_id).single();
          if (currentInv) {
            await supabase.from('inventory').update({ quantity: currentInv.quantity + item.quantity }).eq('id', currentInv.id);
          }
        }
      }
      
      await supabase.from('inventory_transactions').delete().eq('transfer_id', selectedTransfer.id).eq('transaction_type', 'OUT');
      
      await supabase.from('stock_transfers').update({ 
        status: 'Rejected',
        updated_by: currentUser?.id || null,
        updated_by_email: currentUser?.email || null,
        updated_at: new Date().toISOString()
      }).eq('id', selectedTransfer.id);

      showMessage("Transfer Rejected and stock returned to source.", "success");
      setRejectModalOpen(false);
      await fetchCoreData();
    } catch (err: any) {
      showMessage(`Error rejecting transfer: ${err.message}`, "error");
    } finally {
      setIsProcessing(false);
      setRejectStep(1);
    }
  };

  const handleExportExcel = () => {
      const exportData = displayedHistory.map(t => {
        const txnIdString = t.transfer_id ? `TXN-${t.transfer_id.split('-')[0].toUpperCase()}` : `TXN-${t.id.split('-')[0].toUpperCase()}`;
        return {
          "Date": new Date(t.created_at).toLocaleDateString(),
          "System TXN ID": txnIdString,
          "PO / Ref No": t.reference_no || 'N/A',
          "Source": t.exact_source,
          "Receiving Warehouse": t.warehouses?.name || 'Unknown',
          "Product Code": t.products?.code || 'N/A',
          "Product Name": t.products?.name || 'Unknown',
          "Quantity Received (IN)": t.quantity,
          "Unit": t.products?.unit_type || '',
          "Remarks": t.remarks || 'N/A',
          "Logged By (Email)": t.created_by_email || 'System'
        };
      });
  
      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Inbound_Receives");
      XLSX.writeFile(workbook, `Product_Receive_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleExportPDF = () => {
      const doc = new jsPDF('landscape');
      doc.setFontSize(14); doc.setTextColor(30, 41, 59);
      doc.text("Internal Product Receive - Audit Report", 14, 15);
      doc.setFontSize(9); doc.setTextColor(100, 116, 139);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 21);
  
      const tableColumn = ["Date", "TXN ID", "Source WH", "Target WH", "Product Details", "Qty (IN)", "User Audit"];
      const tableRows: any[] = [];
  
      displayedHistory.forEach(t => {
        const txnIdString = t.transfer_id ? `TXN-${t.transfer_id.split('-')[0].toUpperCase()}` : `TXN-${t.id.split('-')[0].toUpperCase()}`;
        tableRows.push([
          new Date(t.created_at).toLocaleDateString(),
          txnIdString,
          t.exact_source,
          t.warehouses?.name || 'N/A',
          `${t.products?.name || 'Unknown'} [${t.products?.code || '-'}]`,
          `+${t.quantity} ${t.products?.unit_type || ''}`,
          t.created_by_email || 'System'
        ]);
      });
  
      autoTable(doc, {
        head: [tableColumn], body: tableRows, startY: 26, theme: 'grid',
        styles: { fontSize: 7.5, cellPadding: 2.5, overflow: 'linebreak' },
        headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255] },
      });
      doc.save(`Product_Receive_Report_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  // --- UI FILTERING LOGIC ---
  const displayedTransfers = pendingTransfers.filter(t => {
      if (!selectedWarehouseId || t.to_warehouse_id !== selectedWarehouseId) return false;
      if (filterDate && !t.created_at.startsWith(filterDate)) return false;
      if (searchQuery) {
          const q = searchQuery.toLowerCase();
          const txnId = `txn-${t.id.split('-')[0]}`.toLowerCase();
          return txnId.includes(q) || (t.reference_no || '').toLowerCase().includes(q) || t.from_warehouse?.name.toLowerCase().includes(q);
      }
      return true;
  });

  const displayedHistory = recentReceives.filter(t => {
      if (!selectedWarehouseId || t.warehouse_id !== selectedWarehouseId) return false;
      if (filterDate && !t.created_at.startsWith(filterDate)) return false;
      if (searchQuery) {
          const q = searchQuery.toLowerCase();
          const txnId = t.transfer_id ? `txn-${t.transfer_id.split('-')[0]}`.toLowerCase() : `txn-${t.id.split('-')[0]}`.toLowerCase();
          return txnId.includes(q) || (t.reference_no || '').toLowerCase().includes(q) || (t.products?.name || '').toLowerCase().includes(q) || (t.exact_source || '').toLowerCase().includes(q);
      }
      return true;
  });

  return (
    <div className="flex flex-col h-full bg-slate-50 w-full animate-in fade-in duration-500 relative">
      <header className="flex h-20 bg-white border-b border-slate-200 items-center px-4 md:px-6 shrink-0 shadow-sm z-10 justify-between">
        <div className="flex items-center">
            <button onClick={() => window.history.back()} className="mr-4 p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors flex items-center justify-center">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            </button>
            <div>
               <h2 className="text-xl md:text-2xl font-bold text-slate-900">Internal Product Receive</h2>
               <p className="text-sm text-slate-500 hidden md:block">Receive products sent from other warehouses</p>
            </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        
        {msg.text && (
          <div className={`p-4 rounded-xl shadow-lg border text-sm font-bold animate-in slide-in-from-top-2 flex justify-between items-center shrink-0 fixed top-24 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md ${msg.type === 'error' ? 'bg-rose-50 text-rose-700 border-rose-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
            <span className="flex items-center"><span className="mr-2 text-lg">{msg.type === 'error' ? '⚠️' : '✅'}</span> {msg.text}</span>
            <button onClick={() => setMsg({text:'', type:''})} className="p-1 rounded-md hover:bg-black/5"><Icons.Close /></button>
          </div>
        )}

        {/* TOP FILTER CARD */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 justify-between md:items-end">
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 text-indigo-600">Receiving Warehouse (Target)</label>
                    <select 
                      value={selectedWarehouseId} 
                      onChange={(e) => setSelectedWarehouseId(e.target.value)} 
                      className="w-full px-4 py-2.5 bg-indigo-50 border border-indigo-200 rounded-xl text-sm text-indigo-900 font-bold outline-none focus:border-indigo-500"
                    >
                        {allowedWarehouses.length === 0 ? (
                            <option value="">-- No Warehouses Assigned --</option>
                        ) : (
                            <option value="" disabled>-- Select Destination --</option>
                        )}
                        {allowedWarehouses.map(w => <option key={w.id} value={w.id}>[{w.code}] {w.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">Filter Date</label>
                    <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 font-bold outline-none focus:border-indigo-500" />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">Search Source / TXN / Item</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><Icons.Search /></div>
                        <input type="text" placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 font-bold outline-none focus:border-indigo-500" />
                    </div>
                </div>
            </div>
        </div>

        {/* PENDING TRANSFERS */}
        <div className="bg-white rounded-2xl border border-amber-200 shadow-sm overflow-hidden flex flex-col shrink-0">
           <div className="p-4 border-b border-amber-200 bg-amber-50 flex justify-between items-center">
              <h3 className="text-sm font-bold text-amber-900 uppercase tracking-wide flex items-center">
                <span className="mr-2 text-lg">🚚</span> Incoming Transfers (Pending)
              </h3>
              <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">{displayedTransfers.length} Pending</span>
           </div>
           
           <div className="p-2 space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar bg-slate-50/50">
              {isLoading ? (
                <div className="p-10 text-center"><Icons.Spinner /></div>
              ) : !selectedWarehouseId ? (
                <div className="p-10 text-center text-sm text-slate-500 font-bold border-2 border-dashed border-slate-200 rounded-xl m-2 bg-white">
                  Please select a Receiving Warehouse from the filter above.
                </div>
              ) : displayedTransfers.length === 0 ? (
                <div className="p-10 text-center text-sm text-slate-500 font-bold border-2 border-dashed border-slate-200 rounded-xl m-2 bg-white">
                  No pending transfers for the selected filter.
                </div>
              ) : (
                displayedTransfers.map(t => {
                  const txnId = `TXN-${t.id.split('-')[0].toUpperCase()}`;
                  return (
                    <div key={t.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white border border-slate-200 rounded-xl shadow-sm hover:border-amber-300 transition-all gap-4">
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                            <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">{new Date(t.transfer_date).toLocaleDateString()}</span>
                            <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">{txnId}</span>
                            {t.reference_no && <span className="text-[10px] font-bold text-slate-500 border border-slate-200 px-2 py-0.5 rounded">PO: {t.reference_no}</span>}
                        </div>
                        <div className="flex items-center space-x-3 mt-2">
                           <div>
                               <p className="text-[9px] font-bold text-slate-400 uppercase">FROM SOURCE</p>
                               <p className="font-bold text-slate-800 text-sm">{t.from_warehouse?.name}</p>
                           </div>
                           <span className="text-slate-300">→</span>
                           <div>
                               <p className="text-[9px] font-bold text-indigo-400 uppercase">TO DESTINATION</p>
                               <p className="font-bold text-indigo-900 text-sm">{t.to_warehouse?.name}</p>
                           </div>
                        </div>
                      </div>
                      
                      <div className="flex flex-row sm:flex-col items-center sm:items-end shrink-0 gap-2 w-full sm:w-auto">
                        <button onClick={() => {setSelectedTransfer(t); setRejectStep(1); setRejectModalOpen(true);}} className="flex-1 sm:flex-none px-4 py-2 bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl hover:bg-rose-100 transition-colors text-center shadow-sm">
                          Reject
                        </button>
                        <button onClick={() => openTransferModal(t)} className="flex-1 sm:flex-none px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-bold rounded-xl shadow-md hover:shadow-lg transition-all text-center">
                          Review & Receive
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
           </div>
        </div>

        {/* RECENT RECEIVES (HISTORY) */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col flex-1 overflow-hidden min-h-[500px]">
           <div className="p-4 border-b border-slate-100 bg-slate-50/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide flex items-center">
                  <span className="mr-2 text-lg">🕒</span> Recent Receives (History)
              </h3>
              <div className="flex space-x-2">
                <button onClick={handleExportExcel} disabled={displayedHistory.length === 0} className="flex items-center px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-xl hover:bg-emerald-100 transition-colors shadow-sm disabled:opacity-50">
                  <Icons.Download /> <span className="ml-1 hidden sm:block">Excel</span>
                </button>
                <button onClick={handleExportPDF} disabled={displayedHistory.length === 0} className="flex items-center px-4 py-2 bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl hover:bg-rose-100 transition-colors shadow-sm disabled:opacity-50">
                  <Icons.Download /> <span className="ml-1 hidden sm:block">PDF</span>
                </button>
              </div>
           </div>

           <div className="flex-1 overflow-y-auto p-3 bg-slate-50/50 space-y-3 custom-scrollbar">
              {isLoading ? (
                <div className="p-10 text-center"><Icons.Spinner /></div>
              ) : !selectedWarehouseId ? (
                <div className="p-10 text-center text-sm text-slate-500 font-bold border-2 border-dashed border-slate-200 rounded-xl m-2 bg-white">
                  Please select a Receiving Warehouse to view history.
                </div>
              ) : displayedHistory.length === 0 ? (
                <div className="p-10 text-center text-sm text-slate-500 font-bold border-2 border-dashed border-slate-200 rounded-xl m-2 bg-white">
                    No transfer history found for the selected filter.
                </div>
              ) : (
                displayedHistory.map(txn => {
                  const txnIdString = txn.transfer_id ? `TXN-${txn.transfer_id.split('-')[0].toUpperCase()}` : `TXN-${txn.id.split('-')[0].toUpperCase()}`;
                  
                  return (
                    <div key={txn.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-indigo-300 transition-colors">
                      <div className="flex-1">
                        <div className="flex flex-wrap gap-2 items-center mb-2">
                           <span className="text-[10px] font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">{new Date(txn.created_at).toLocaleDateString()}</span>
                           <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">{txnIdString}</span>
                           {txn.reference_no && <span className="text-[10px] font-bold text-slate-500 border border-slate-200 px-2 py-0.5 rounded">PO/Ref: {txn.reference_no}</span>}
                        </div>
                        
                        <div className="flex items-center space-x-2 my-2">
                           <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${txn.products?.product_type === 'LPG' ? 'bg-orange-50 text-orange-600 border border-orange-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
                             {txn.products?.product_type}
                           </span>
                           <p className="font-bold text-slate-800 text-sm truncate">{txn.products?.name}</p>
                        </div>
                        
                        <div className="flex items-center gap-4 mt-2 border-t border-slate-100 pt-2">
                          <span className="text-xs text-slate-500">
                            <span className="text-[9px] font-bold text-slate-400 uppercase mr-1">Source:</span> 
                            <span className="font-semibold text-slate-800">{txn.exact_source}</span>
                          </span>
                          <span className="text-xs text-slate-500">
                            <span className="text-[9px] font-bold text-slate-400 uppercase mr-1">Target WH:</span> 
                            <span className="font-semibold text-slate-800">{txn.warehouses?.name}</span>
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between sm:flex-col sm:items-end gap-2 border-t border-slate-100 pt-3 sm:border-0 sm:pt-0 shrink-0">
                        <div className="text-right flex items-center">
                          <span className="font-black text-emerald-600 text-2xl">+{txn.quantity}</span>
                          <span className="text-[10px] font-bold text-slate-500 uppercase ml-1">{txn.products?.unit_type}</span>
                        </div>
                        <button onClick={() => {setSelectedTransaction(txn); setDetailsModalOpen(true);}} className="text-[10px] font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition-colors border border-indigo-200 mt-2 shadow-sm">
                          View Details
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
           </div>
        </div>
      </div>

      {/* --- RECEIVE MODAL --- */}
      {transferModalOpen && selectedTransfer && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-black text-slate-900 text-lg">Receive Internal Transfer</h3>
                <p className="text-xs font-bold text-indigo-600 mt-0.5">TXN-{selectedTransfer.id.split('-')[0].toUpperCase()} • To {selectedTransfer.to_warehouse?.name}</p>
              </div>
              <button onClick={() => setTransferModalOpen(false)} className="text-slate-400 hover:text-slate-700 bg-white p-2 rounded-xl border border-slate-200 shadow-sm"><Icons.Close /></button>
            </div>
            
            <div className="p-6 flex-1 overflow-y-auto space-y-4 custom-scrollbar">
               <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Transferred Items to Receive</h4>
               <div className="space-y-3">
                 {transferItems.map((item, idx) => (
                   <div key={idx} className="flex items-center justify-between p-4 rounded-xl border border-slate-200 bg-white shadow-sm hover:border-emerald-300 transition-colors">
                     <div className="flex items-center space-x-3">
                       <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${item.products?.product_type === 'LPG' ? 'bg-orange-100 text-orange-700' : 'bg-emerald-100 text-emerald-700'}`}>
                         {item.products?.product_type}
                       </span>
                       <div>
                         <p className="text-sm font-bold text-slate-900">{item.products?.name}</p>
                         <p className="text-[10px] text-slate-500 font-mono mt-0.5">{item.products?.code}</p>
                       </div>
                     </div>
                     <div className="text-right">
                       <p className="text-lg font-black text-emerald-600">+{item.quantity}</p>
                       <p className="text-[10px] font-bold text-slate-400 uppercase">{item.products?.unit_type}</p>
                     </div>
                   </div>
                 ))}
               </div>
            </div>

            <div className="p-5 border-t border-slate-200 bg-slate-50 shrink-0">
               <button onClick={handleConfirmReceive} disabled={isProcessing} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-md flex justify-center items-center disabled:opacity-50">
                 {isProcessing ? <><Icons.Spinner /> Processing...</> : '✅ Confirm & Add to Inventory'}
               </button>
            </div>
          </div>
        </div>
      )}

      {/* --- REJECT MODAL --- */}
      {rejectModalOpen && selectedTransfer && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-rose-200 bg-rose-50 flex justify-between items-center">
              <h3 className="font-black text-rose-900 text-lg">Reject Transfer</h3>
              <button onClick={() => setRejectModalOpen(false)} className="text-rose-400 hover:text-rose-700 bg-white p-1.5 rounded-lg border border-rose-200"><Icons.Close /></button>
            </div>
            
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">⚠️</div>
              
              {rejectStep === 1 ? (
                <>
                  <h4 className="text-lg font-bold text-slate-900 mb-2">Are you sure?</h4>
                  <p className="text-sm text-slate-500 mb-6 leading-relaxed">You are about to reject <span className="font-bold">TXN-{selectedTransfer.id.split('-')[0].toUpperCase()}</span> from <span className="font-bold">{selectedTransfer.from_warehouse?.name}</span>.</p>
                  <button onClick={() => setRejectStep(2)} className="w-full bg-rose-500 hover:bg-rose-600 text-white font-bold py-3.5 rounded-xl shadow-md transition-all">Yes, Proceed to Reject</button>
                  <button onClick={() => setRejectModalOpen(false)} className="w-full bg-slate-100 text-slate-600 hover:bg-slate-200 font-bold py-3.5 rounded-xl mt-3 transition-all">Cancel</button>
                </>
              ) : (
                <>
                  <h4 className="text-lg font-bold text-rose-600 mb-2">Final Confirmation</h4>
                  <p className="text-sm text-slate-600 mb-6 bg-rose-50 p-4 rounded-xl border border-rose-100 leading-relaxed">Click below to permanently reject this transfer. The deducted stock will be returned to the source warehouse.</p>
                  <button onClick={handleRejectTransfer} disabled={isProcessing} className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-3.5 rounded-xl shadow-md transition-all flex justify-center items-center disabled:opacity-50">
                    {isProcessing ? <><Icons.Spinner /> Returning Stock...</> : 'Confirm Rejection'}
                  </button>
                  <button onClick={() => setRejectModalOpen(false)} className="w-full bg-slate-100 text-slate-600 hover:bg-slate-200 font-bold py-3.5 rounded-xl mt-3 transition-all">Cancel</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- DETAILS MODAL --- */}
      {detailsModalOpen && selectedTransaction && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
              <h3 className="font-black text-slate-900 text-lg">Transaction Details</h3>
              <button onClick={() => setDetailsModalOpen(false)} className="text-slate-400 hover:text-slate-700 bg-white p-2 rounded-lg border border-slate-200 shadow-sm"><Icons.Close /></button>
            </div>
            <div className="p-6 space-y-5">
               <div>
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Transaction ID & Date</p>
                 <p className="font-black text-indigo-700 text-lg">
                   {selectedTransaction.transfer_id ? `TXN-${selectedTransaction.transfer_id.split('-')[0].toUpperCase()}` : `TXN-${selectedTransaction.id.split('-')[0].toUpperCase()}`}
                 </p>
                 <p className="text-xs font-bold text-slate-500 mt-1">{new Date(selectedTransaction.created_at).toLocaleString()}</p>
               </div>
               
               <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4 shadow-sm">
                 <div>
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Product</p>
                   <p className="font-bold text-slate-900 text-sm mt-0.5">{selectedTransaction.products?.name}</p>
                 </div>
                 
                 <div className="flex justify-between items-center pt-4 border-t border-slate-200">
                   <div>
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Quantity Received</p>
                     <p className="font-black text-emerald-600 text-xl mt-0.5">+{selectedTransaction.quantity} <span className="text-[10px] font-bold text-slate-500 uppercase ml-1">{selectedTransaction.products?.unit_type}</span></p>
                   </div>
                   <div className="text-right">
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">PO / Ref No</p>
                     <p className="font-bold text-slate-800 text-sm mt-0.5">{selectedTransaction.reference_no || 'N/A'}</p>
                   </div>
                 </div>

                 <div className="flex justify-between items-start pt-4 border-t border-slate-200">
                   <div className="flex-1 pr-3">
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Source / From</p>
                     <p className="font-bold text-slate-800 text-sm mt-0.5">{selectedTransaction.exact_source}</p>
                   </div>
                   <div className="text-right flex-1 pl-3 border-l border-slate-200">
                     <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Target Warehouse</p>
                     <p className="font-bold text-indigo-900 text-sm mt-0.5">{selectedTransaction.warehouses?.name}</p>
                   </div>
                 </div>
               </div>

               <div>
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Remarks & Audit</p>
                 <p className="text-sm font-medium text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200 leading-relaxed">{selectedTransaction.remarks || 'No remarks provided.'}</p>
                 <p className="text-[10px] font-bold text-slate-400 mt-2 font-mono bg-slate-100 inline-block px-2 py-1 rounded">Logged by: {selectedTransaction.created_by_email || 'System'}</p>
               </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}